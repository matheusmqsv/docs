2. não altere a configuração do npm nem o shell rc, não instale nada e não rode `qa-agent install`;
3. não invoque outras skills;
4. depois de gravar `specs/automacao-mobile/qa-agent-status.txt`, emita `[step:done]` e encerre o turno imediatamente.

## Verificar e persistir

O comando roda com o diretório do repositório como working-directory. Detecte a versão do CLI e a versão do Node (o QA Agent exige **Node.js >= 22**):

```bash
PROJECT_DIR="$(pwd)"
mkdir -p "$PROJECT_DIR/specs/automacao-mobile"

STATUS="nao-instalado"
if qa-agent --version >/dev/null 2>&1; then
  STATUS="instalado"
fi

printf '%s\n' "$STATUS" > "$PROJECT_DIR/specs/automacao-mobile/qa-agent-status.txt"

echo "qa-agent: $(qa-agent --version 2>/dev/null || echo 'ausente')"
echo "node: $(node --version 2>/dev/null || echo 'ausente')"
echo "STATUS=$STATUS"
```

## Reportar

- Se `STATUS=instalado`: informe a versão do `qa-agent` e siga.
- Se `STATUS=nao-instalado`: informe que o CLI será configurado e instalado nos próximos steps.
- Se o `node --version` for menor que 22 (ou ausente): avise o usuário que o QA Agent exige **Node.js >= 22** e que a instalação pode falhar sem essa versão. Não bloqueie o step por causa disso - apenas registre o aviso.

O conteúdo do arquivo deve ser exatamente `instalado` ou `nao-instalado`. Confirme que o arquivo existe com um desses dois valores. Em seguida, emita `[step:done]` e encerre. Não execute o próximo step.
