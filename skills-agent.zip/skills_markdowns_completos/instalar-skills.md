Instala no repositório de automação as skills de qualidade mobile necessárias ao fluxo, usando o QA Agent CLI. As skills e os MCPs declarados por elas (nqd-mcp, hopper, gestao-experiencia) são gravados no **local de config do provedor de IA que está rodando esta sessão** - o próprio `qa-agent install` decide o destino a partir da flag `-a`. Os próximos steps (subagents) carregam essas skills automaticamente.

## Escopo obrigatório

Quando esta skill estiver vinculada ao step **Instalar skills mobile**:

1. execute somente o `qa-agent install` descrito abaixo;
2. não altere código do projeto nem configure a automação (isso vem nos steps seguintes);
3. não invoque outras skills;
4. ao final, emita `[step:done]` e encerre o turno.

## Escolher o agente correto (`-a`)

A flag `-a` diz ao `qa-agent install` **em qual provedor** instalar as skills e os MCPs. Ela precisa corresponder ao agente que está executando ESTA sessão do DJ - senão as skills serão instaladas no provedor errado e os próximos steps não as encontrarão. Identifique-se e escolha:

- Se **você é o Claude Code** - use `-a claude-code` (skills em `<repo>/.claude/skills/`, MCPs em `<repo>/.mcp.json`).
- Se **você é o Devin** - use `-a devin` (skills e MCPs no local de config do Devin).

Use exatamente o valor do provedor que está rodando agora. Nas instruções abaixo, `<AGENTE>` = o valor escolhido aqui.

## Confirmar o diretório-alvo (obrigatório antes de instalar)

O alvo (`-t`) **precisa** ser o repositório selecionado pelo usuário no gate **Selecionar repositório** - nunca o diretório do servidor DJ.

- **Use `$(pwd)`** (comando, que retorna o working-directory real do processo - o DJ o define como o repositório selecionado). **Nunca use `$PWD`**: essa variável é herdada do processo do servidor DJ e aponta para o diretório dele, fazendo a instalação cair no lugar errado.
- O caminho do repositório selecionado chega no contexto deste step sob a key **`repo-path`** (rótulo "Repositório de trabalho selecionado"). **Compare** `$(pwd)` com esse caminho: se **não** forem o mesmo diretório (ou se `$(pwd)` for o repositório do DJ / qualquer outro), **PARE** - reporte o problema ao usuário e **não** rode o install nem emita `[step:done]`.

```bash
REPO_DIR="$(pwd)"
echo "Diretório-alvo da instalação (deve ser o repositório selecionado): $REPO_DIR"
```

## Instalar as skills mobile

O `qa-agent install` é idempotente - pode rodar novamente sem efeitos colaterais. Substitua `<AGENTE>` pelo provedor identificado acima. O alvo é sempre `"$REPO_DIR"` (definido acima), nunca `$PWD`.

No macOS/Linux (bash/zsh) prefixe com `export NODE_TLS_REJECT_UNAUTHORIZED=0`; no Windows (PowerShell) rode antes `$env:NODE_TLS_REJECT_UNAUTHORIZED = "0"` na mesma sessão. Não persista essa variável no shell rc.

```bash
export NODE_TLS_REJECT_UNAUTHORIZED=0
qa-agent install \
  assert-mobile-skill \
  automation-superapp-mobile \
  gestao-experiencia \
  hopper \
  mobile-infra-preflight \
  qa-core \
  test-design \
  test-planning \
  -a <AGENTE> \
  -t "$REPO_DIR"
```

## Validar a instalação (fail-loud, no diretório certo)

Valide **sempre** contra `"$REPO_DIR"` (o repositório selecionado) - nunca `$PWD`. A verificação de status é agnóstica de provedor:

```bash
qa-agent status -t "$REPO_DIR"
```

Confirme que as **8 skills** aparecem no `qa-agent status`. Em seguida, valide que os artefatos foram gravados **dentro de `$REPO_DIR`**, no local do provedor que você usou no `-a`:

- **`-a claude-code`**: skills em `$REPO_DIR/.claude/skills/` e MCPs (`nqd-mcp`, `hopper`, `gestao-experiencia`) em `$REPO_DIR/.mcp.json`:

  ```bash
  ls "$REPO_DIR/.claude/skills/"
  cat "$REPO_DIR/.mcp.json" 2>/dev/null || echo "(.mcp.json ausente - reporte ao usuário)"
  ```

- **`-a devin`**: skills em `$REPO_DIR/.devin/skills/`:

  ```bash
  ls "$REPO_DIR/.devin/skills/"
  ```

Os MCPs serão lidos automaticamente pelo agente nos steps de contexto e implementação.

## Encerrar

Trate como **falha** (reporte e **não** emita `[step:done]`) se: o `qa-agent status` não listar as 8 skills; o diretório de skills do provedor (`$REPO_DIR/.claude/skills/` ou `$REPO_DIR/.devin/skills/`) não existir ou estiver vazio; ou a instalação tiver caído em qualquer diretório diferente de `$REPO_DIR` (ex.: o repositório do servidor DJ). Nesse caso, provável causa adicional: source do catálogo não configurada - verifique `qa-agent config --show`.

Só com as **8 skills confirmadas dentro de `$REPO_DIR`**, informe ao usuário o resumo **incluindo o diretório onde instalou**, emita `[step:done]` e encerre. Não execute o próximo step.
