Executa a validação estática completa da automação Assert Mobile gerada: dependências Python, dryrun da suíte (sintaxe + imports sem Appium), lint Robocop e alinhamento de tags com mass data. Bloqueia o avanço enquanto houver erros.

## Escopo obrigatório

Quando esta skill estiver vinculada ao step **Lint e validação estática**:

1. execute somente as validações estáticas descritas abaixo;
2. não execute os testes de fato (sem Appium/device - isso é do grupo de execução);
3. não invoque outras skills;
4. só emita `[step:done]` quando **todas** as validações passarem sem erro.

## Executar as validações

O comando roda com o diretório do repositório como working-directory:

```bash
# 0. Resolver o diretório de skills do provedor (claude-code ou devin)
SKILLS_DIR=""
for d in .claude/skills .devin/skills; do
  if [ -f "$d/assert-mobile-skill/SKILL.md" ]; then SKILLS_DIR="$d"; break; fi
done

# 1. Dependências Python
pip install -r requirements.txt --upgrade

# 2. Dryrun - valida sintaxe + imports sem precisar de Appium/device
robot --dryrun -V devdata/env.yaml tests/*.robot

# 3. Lint Robocop
robocop check features/ tests/

# 4. Alinhamento de tags + mass data
python3 "$SKILLS_DIR/assert-mobile-skill/scripts/validators/check_mass_tag_alignment.py" --project-root .
```

> Ajuste os caminhos (`tests/`, `features/`, `devdata/env.yaml`) conforme a estrutura real detectada - em projetos `existente-variante` a organização pode diferir do scaffold default. Se `$SKILLS_DIR` ficar vazio (skills do provedor não encontradas), reporte ao usuário - provável falha no step "Instalar skills mobile".

## Tratar resultado

- **Qualquer passo falhou** - reporte o erro (comando, saída relevante e arquivo afetado) e **aguarde instrução do usuário**. Não emita `[step:done]`.
- **Zero erros nos quatro passos** - informe o resumo (dryrun OK, Robocop limpo, tags/mass data alinhados), emita `[step:done]` e encerre.

Não execute o próximo step.
