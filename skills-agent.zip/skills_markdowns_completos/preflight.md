Executa o preflight de infraestrutura mobile (skill `mobile-infra-preflight`, instalada em `.claude/skills/`), verificando que o ambiente está pronto para rodar os testes com Appium. Bloqueia o avanço enquanto algum check falhar.

## Escopo

Quando esta skill estiver vinculada ao step **Preflight - verificar ambiente**:

1. execute o preflight e reporte os checks;
2. não execute os testes de fato (isso é do próximo step, `executar`);
3. só emita `[step:done]` quando todos os checks passarem - ou quando o usuário decidir explicitamente prosseguir após tratar as pendências.

## Executar o preflight

O comando roda com o diretório do repositório como working-directory:

```bash
python3 .claude/skills/mobile-infra-preflight/scripts/preflight_check.py
```

O script verifica 5 pontos: **device/emulator ativo**, **Appium na porta 4723**, **app instalado**, **appActivity discovery** e **capabilities seguras**.

## Tratar resultado

- **Algum check falhou** - reporte qual(is) check(s) falharam e o motivo, aponte a ação de correção (consulte `.claude/skills/mobile-infra-preflight/references/troubleshooting.md`) e **aguarde a resolução do usuário**. Como este é um step interativo, o usuário pode corrigir o ambiente e pedir para revalidar - rode o preflight novamente. Não emita `[step:done]` com checks vermelhos, salvo instrução explícita do usuário.
- **Todos os 5 checks passaram** - informe o resumo, emita `[step:done]` e encerre.

Não execute o próximo step.
