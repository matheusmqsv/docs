Implementa a automação mobile Assert Mobile para o SuperApp PF a partir dos cenários já aprovados, **carregando e seguindo em tempo de execução** as skills instaladas do provedor (`assert-mobile-skill` como autoridade de convenções e `automation-superapp-mobile` como context builder de domínio). Ao final, o usuário valida a entrega antes de seguir para o lint.

## Escopo

Quando esta skill estiver vinculada ao step **Implementar automação**:

1. faça o bootstrap das skills do provedor (abaixo) e **siga** as convenções carregadas;
2. gere os artefatos de automação (features, resources/locators, testdata, infraestrutura);
3. não execute os testes nem o preflight de ambiente (isso é do grupo de execução);
4. conduza o trabalho de forma autônoma; ao concluir todos os artefatos e rodar os validators, emita `[step:done]` - o DJ abrirá o gate de validação humana.

## Carregar as skills do provedor (bootstrap em runtime)

O DJ injeta apenas o texto desta skill - **não** carrega as `references/`, `templates/` nem os `scripts/validators/` das skills de catálogo. Por isso, **antes de gerar qualquer artefato**, leia e **siga** os arquivos das skills instaladas do provedor direto do repositório (você tem acesso a shell e leitura de arquivos, com o repositório como working-directory). Estes são os **arquivos de catálogo instalados do provedor** - distintos das skills de workflow do DJ (`/.dj:*`); lê-los do disco é esperado e permitido.

1. Resolva o diretório de skills do provedor (coerente com o step "Instalar skills mobile"):

```bash
SKILLS_DIR=""
for d in .claude/skills .devin/skills; do
  if [ -f "$d/assert-mobile-skill/SKILL.md" ]; then SKILLS_DIR="$d"; break; fi
done
echo "Skills do provedor em: ${SKILLS_DIR:-<não encontrado>}"
```

2. Para **cada** skill de catálogo abaixo, **leia o `SKILL.md` e siga seus `loadLevels`/sub-recursos** - abra as `references/`/`templates/` que o próprio `SKILL.md` mandar carregar para o caso atual e prepare os `scripts/validators/`. Não apenas cite: **carregue e obedeça**.
- `$SKILLS_DIR/assert-mobile-skill/SKILL.md` - **autoridade de convenções** Robot Framework (arquitetura POM, keywords, tags/massa, snapshots, robocop, validators). Carregue os níveis de geração de automação (rules, conventions, locator-sourcing, superapp-interaction-patterns, generation-workflows e os templates de suite/resources).
- `$SKILLS_DIR/automation-superapp-mobile/SKILL.md` - **context builder de domínio** (grafo de jornadas, locators calibrados, KB de enriquecimento) que alimenta a geração via MCP `nqd_*`.

## IMPORTANTE - discovery já ocorreu

A fase de discovery de cenários (Phase 0.5 / Round 1-2 da `assert-mobile-skill`) **já foi executada** pelo fluxo do DJ nos steps anteriores. Os cenários aprovados chegam no contexto sob a key `context-cenarios` (arquivo `specs/automacao-mobile/contexto-cenarios.md`). **Não repita as perguntas de Round 1/Round 2** - use esses cenários como input e vá direto para a geração. Isso **não reduz o rigor**: cubra **todos** os cenários aprovados aplicando as convenções carregadas (não caia em 2-3 genéricos nem deixe cenários sem artefato).

## Detecção de projeto (nativa da assert-mobile-skill)

A própria `assert-mobile-skill` detecta se já existe um projeto de automação no repositório e escolhe o caminho - não faça uma etapa de detecção separada nem persista `tipo-projeto`; deixe a skill conduzir:

- **projeto novo** (sem automação detectada) - a skill copia o scaffold de infraestrutura (`requirements.txt`, `robocop.toml`, `devdata/`, `testdata/` - template em `$SKILLS_DIR/assert-mobile-skill/templates/assert-mobile-scaffold/`) e cria a primeira feature.
- **projeto existente** - a skill lê arquivos representativos para extrair as convenções (nomenclatura, estrutura de recursos, tags, mass data) **antes** de gerar, mantendo consistência com o que já existe.

## Enriquecimento de domínio + locators reais (MCP)

Antes de escrever os arquivos `.resource` de locators, enriqueça com a `automation-superapp-mobile`: quando aplicável, consulte `hopper`/`gestao-experiencia` via MCP e **injete** o resultado em `nqd_hydrate_task`/`nqd_build_subgraph` para hidratar jornadas e **locators reais** do SuperApp. **Não invente seletores** - use os locators hidratados. A `automation-superapp-mobile` provê o contexto de domínio; a `assert-mobile-skill` continua sendo a autoridade das convenções ao materializar os artefatos.

## Rodar os validators (antes de encerrar)

Depois de gerar/alterar os artefatos e **antes** de `[step:done]`, rode os validators da skill (do diretório do provedor resolvido) e garanta **zero erros/warnings**:

```bash
python3 "$SKILLS_DIR/assert-mobile-skill/scripts/validators/check_layer_architecture.py" --project-root .
python3 "$SKILLS_DIR/assert-mobile-skill/scripts/validators/check_mass_tag_alignment.py" --project-root .
```

(O `robocop check` e o `robot --dryrun` completos rodam no step de lint seguinte, mas resolva aqui qualquer apontamento que os validators indicarem - não deixe buracos para o lint.)

## Fallback mínimo (se as skills do provedor não forem encontradas)

Se `$SKILLS_DIR` ficar vazio ou o `SKILL.md` alvo não existir, **avise o usuário** que as skills instaladas do provedor não foram encontradas no caminho esperado (possível falha no step "Instalar skills mobile") e, como rede de segurança, aplique este checklist essencial ao gerar (propositalmente enxuto - a fonte de verdade são os arquivos de catálogo):

- **Cadeia POM em 5 camadas, não puláveis**: `Suite -> Steps -> Pages (aggregator) -> Page -> Locator`. O aggregator está sempre presente (mesmo com 1 Page).
- `Library AppiumLibrary` **antes** de `AssertMobile`, e **só** na suíte `.robot`.
- **Nunca** declarar `Suite Setup`/`Test Setup`/`Test Teardown` (auto-injetados pela AssertMobile); login/seleção de ambiente vão explícitos no `Test Case`.
- **Locators sempre XPath**, com os **mesmos nomes de variável** em android e ios (muda só a expressão).
- `Salvar Snapshot XML` **não é keyword nativa** - confirme que já existe no projeto ou defina-a (`Get Source` + `Create File`, requer `Library OperatingSystem`).
- **Nunca** editar `robocop.toml` para silenciar apontamento - corrija no `.robot`/`.resource`.
- `devdata/env.yaml` (config de execução, via `-V`) separado de `testdata/massa_${AMBIENTE}.yaml` (dados, via `Variables`); massa dedicada em `feature.<tagÚnica>.<campo>`, sem reusar chaves.
- **Tags em camelCase** (exceto `QAAgent`), **uma tag única por cenário**; gate `QAAgent` (suíte nova -> `Test Tags QAAgent`; suíte existente -> só no `[Tags]` dos cenários novos/alterados).
- **Âncora pós-login**: validar que a home abriu antes da 1ª ação do módulo (reusar keyword existente, sem clique artificial).
- **Disciplina de escopo**: gerar só o que foi pedido; não copiar `features/login/` do scaffold; se a feature depende de login e o projeto não tem, **pare e pergunte**.
- Sem wait duplicado antes de `Clicar Em Elemento`/`Preencher Texto Em Elemento`; reusar `Rolar ... Até Encontrar Elemento`.

## Encerrar

Ao concluir todos os artefatos (features, resources/locators, testdata e infraestrutura conforme o tipo de projeto) e passar nos validators, faça um resumo do que foi gerado (incluindo se leu as skills do provedor ou caiu no fallback) e emita `[step:done]`. O DJ apresentará o gate de validação humana - só siga para o lint após a aprovação. Se o usuário reprovar, aplique os ajustes solicitados e reapresente.
