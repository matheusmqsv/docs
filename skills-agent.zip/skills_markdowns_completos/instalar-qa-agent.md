Instala o QA Agent CLI (`@qa-agent/cli`) globalmente via npm e configura a **source** do catálogo de skills (`@qa-agent-nqd/catalog`) no Artifactory release va3. Baseado no guia oficial de instalação do QA Agent.

## Escopo obrigatório

Quando esta skill estiver vinculada ao step **Instalar QA Agent CLI**:

1. execute somente a instalação do CLI e a configuração da source descritas abaixo;
2. não rode `qa-agent install <skills>` (isso é do próximo step);
3. não invoque outras skills;
4. ao final, emita `[step:done]` e encerre o turno.

## Idempotência (status recebido no contexto)

O contexto injetado traz `qa-agent-status`. **Se `qa-agent-status = instalado`**, pule a instalação via npm (o CLI já existe) e vá direto para a etapa **Configurar a source do catálogo** abaixo - ela precisa rodar mesmo com o CLI já instalado, para garantir que o `qa-agent install` do próximo step encontre as skills. Depois, emita `[step:done]`.

## Instalar o CLI (quando não-instalado)

O npm já foi apontado para o Artifactory no step anterior (`npm config set`). Instale globalmente:

```bash
# macOS/Linux (bash/zsh)
export NODE_TLS_REJECT_UNAUTHORIZED=0
npm install -g @qa-agent/cli
qa-agent --version
```

```powershell
# Windows (PowerShell)
$env:NODE_TLS_REJECT_UNAUTHORIZED = "0"
npm install -g @qa-agent/cli
qa-agent --version
```

> `NODE_TLS_REJECT_UNAUTHORIZED=0` é exportado **só nesta sessão do comando** (não persista no shell rc). Use o bloco do SO em que você está rodando.

Se `qa-agent --version` falhar após o install, verifique se o diretório global do npm (`npm prefix -g`) está no `PATH` e reporte ao usuário. Não prossiga sem uma versão válida.

## Configurar a source do catálogo (sempre)

Sem apontar a source, o `qa-agent install` do próximo step não tem de onde baixar as skills. Aponte para o pacote `@qa-agent-nqd/catalog` no registry release do va3:

```bash
qa-agent config \
  --set-registry "https://artifactory.prod.aws.cloud.ihf/artifactory/api/npm/itau-va3-npm-release/" \
  --set-package "@qa-agent-nqd/catalog"

qa-agent config --show
```

## Encerrar

Confirme que `qa-agent --version` retorna uma versão e que `qa-agent config --show` aponta para o registry release e o pacote `@qa-agent-nqd/catalog`. Informe a versão ao usuário. Em seguida, emita `[step:done]` e encerre. Não execute o próximo step.
