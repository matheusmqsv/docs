Executa os testes de automação mobile conforme a escolha do QA (execução com TaaC ID para GMUD, ou exploratória), usando o `robothelper`. Este step nunca dispara sozinho - sempre aguarda a decisão explícita do usuário.

## Escopo

Quando esta skill estiver vinculada ao step **Executar testes**:

1. apresente as opções de execução, aguarde a escolha do usuário e execute conforme selecionado;
2. não altere a automação nem regenere artefatos (o fluxo de implementação já foi concluído e validado);
3. só emita `[step:done]` depois de a execução terminar (ou de o usuário optar por encerrar).

## Apresentar as opções e aguardar

Este step é interativo e não deve auto-disparar. Apresente e aguarde a resposta:

```
Como deseja executar os testes?

[opcoes]
- Executar com TaaC ID (robothelper run-taac) - necessário para GMUD
- Execução exploratória (robothelper run) - sem TaaC ID
- Encerrar por aqui
[/opcoes]
```

## Executar conforme a escolha

- **TaaC ID** - rode `robothelper run-taac` (o comando roda com o diretório do repositório como working-directory). Ao final, capture o TaaC ID gerado no formato `AssertMobile:<uuid>`.
- **Exploratória** - rode `robothelper run`. Sem TaaC ID (não serve para GMUD).
- **Encerrar** - não execute nada; informe que o fluxo foi encerrado por escolha do usuário e emita `[step:done]`.

Ajuste os argumentos do `robothelper` (suite/tags/env) conforme a estrutura real do projeto e o que o usuário indicar.

## Pós-execução (TaaC)

Após execução com TaaC, oriente o usuário a **registrar o TaaC ID (`AssertMobile:<uuid>`) no Hopper** para obter o ID TM, que tem validade de 15 dias e é usado no processo de GMUD. Reporte o resultado da execução (passou/falhou, evidências) ao usuário.

## Encerrar

Depois de a execução concluir e reportar o resultado (ou de o usuário optar por encerrar), emita `[step:done]` e encerre.
